# 🏨 Hotel Booking Chatbot — Amazon Lex V2 + AWS Lambda

A conversational hotel-booking chatbot built with **Amazon Lex V2** and **AWS Lambda**.

The chatbot collects booking details through a natural-language conversation and uses a Lambda fulfillment function to calculate the booking price and return a formatted confirmation.

## ✨ Features

- Conversational hotel-room booking
- City selection
- Room-type selection
- Check-in date collection
- Number of nights
- Number of guests
- Booking confirmation
- Dynamic room pricing
- Room-specific descriptions
- Guest-based messages
- Improved final booking summary
- Basic input validation
- Handles the common `duluxe` → `deluxe` spelling mistake

## 🛠️ Tech Stack

- **Amazon Lex V2** — conversational interface and slot collection
- **AWS Lambda** — serverless fulfillment logic
- **Node.js** — Lambda runtime
- **JavaScript** — backend logic

## 🧠 Conversation Flow

```text
User
  ↓
Amazon Lex V2
  ↓
bookhotelroom Intent
  ↓
Collect required slots
  ├── CityName
  ├── roomType
  ├── CheckInDate
  ├── NoofNights
  └── NoofGuest
  ↓
Confirmation
  ↓
AWS Lambda Fulfillment
  ↓
Calculate price + generate response
  ↓
Booking confirmation
```

## 📋 Intent and Slots

### Intent

`bookhotelroom`

### Required slots

| Slot | Type | Purpose |
|---|---|---|
| `CityName` | `AMAZON.City` | Destination city |
| `roomType` | Custom slot type | Room category |
| `CheckInDate` | `AMAZON.Date` | Check-in date |
| `NoofNights` | `AMAZON.Number` | Length of stay |
| `NoofGuest` | `AMAZON.Number` | Number of guests |

### Room types

| Room | Price / Night | Description |
|---|---:|---|
| Classic | ₹3,000 | Comfortable and affordable for a relaxing stay. |
| Deluxe | ₹4,500 | A spacious room with upgraded comfort. |
| Duplex | ₹6,000 | A two-level room ideal for families. |
| Suite | ₹8,000 | A premium room with extra space and comfort. |

## 💻 Lambda Fulfillment

The Lambda function:

1. Reads the values collected by Amazon Lex.
2. Validates the required slots.
3. Normalizes the room type.
4. Calculates the total price:

   `Total = Price per night × Number of nights`

5. Generates a room-specific description.
6. Adds a guest-based message.
7. Returns a formatted booking confirmation to Lex.

## 📸 Screenshots

Add screenshots of the working Amazon Lex conversation and Lambda function to the `screenshots/` directory.

Recommended screenshots:

- Lex bot / intent configuration
- Slot collection
- Room-type prompt
- Successful booking conversation
- Lambda function
- Final booking confirmation

## 📁 Project Structure

```text
hotel-booking-chatbot-aws/
├── lambda/
│   └── index.js
├── screenshots/
│   └── .gitkeep
├── .gitignore
└── README.md
```

## 🚀 Setup

### 1. Amazon Lex V2

Create an Amazon Lex V2 bot and configure the `bookhotelroom` intent with the required slots.

Create a custom `roomType` slot type containing:

```text
Classic
Deluxe
Duplex
Suite
```

Configure the confirmation step and Lambda fulfillment.

### 2. AWS Lambda

Create a Lambda function using a Node.js runtime.

Copy the contents of:

```text
lambda/index.js
```

into the Lambda function and connect the function to the appropriate Lex V2 bot alias.

### 3. Test

Start a conversation such as:

```text
User: I want to book a hotel room

Bot: Which city do you want to stay in?

User: Mumbai

Bot: What type of room do you want?

User: Deluxe

Bot: What is your check-in date?

User: 29 July 2025

Bot: How many nights will you stay?

User: 4

Bot: How many guests will be staying?

User: 5
```

The Lambda fulfillment function then calculates the total price and returns the booking confirmation.

## ⚠️ Security

Do **not** commit:

- AWS access keys
- AWS secret keys
- `.env` files containing credentials
- Passwords
- API keys
- Other private credentials

This repository contains source code and documentation only.

## 📌 Project Scope

This is an educational/demo hotel-booking chatbot. The current implementation calculates a booking price and returns a confirmation response; it does not connect to a real hotel inventory or payment system.

## 📄 License

This project is intended for educational and portfolio use.
